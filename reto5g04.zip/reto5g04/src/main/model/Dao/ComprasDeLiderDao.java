public class ComprasDeLiderDao {
    
}
