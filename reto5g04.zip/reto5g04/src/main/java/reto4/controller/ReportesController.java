package reto4.controller;

import java.sql.SQLException;
import java.util.List;
import reto4.model.dao.*;
import reto4.model.vo.*;

public class ReportesController {
    private ListarHomecenterDao listarHomecenterDao;
    private ListarLideresDao listarLideresDao;
    private ListarCasaCampestreDao listarCasaCampestreDao;

    public ReportesController(){
        listarHomecenterDao = new ListarHomecenterDao();
        listarLideresDao = new ListarLideresDao();
        listarCasaCampestreDao = new ListarCasaCampestreDao();
    }

    public List<ListarHomecenterVo> listarHomecenter() throws SQLException{
        return listarHomecenterDao.listar();        
    }

    public List<ListarLideresVo> listarLideres() throws SQLException{
        return listarLideresDao.listar();
    }

    public List<ListarCasaCampestreVo> listarCasaCampestre() throws SQLException{
        return listarCasaCampestreDao.listar();
    }

}
