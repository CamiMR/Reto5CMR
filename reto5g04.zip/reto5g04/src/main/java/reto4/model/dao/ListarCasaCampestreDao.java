package reto4.model.dao;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import reto4.model.vo.ListarCasaCampestreVo;
import reto4.util.JDBCUtilities;

public class ListarCasaCampestreDao {
    public List<ListarCasaCampestreVo> listar() throws SQLException{
        List<ListarCasaCampestreVo> respuesta = new ArrayList<ListarCasaCampestreVo>();
        Connection conn = JDBCUtilities.getConnection();
        Statement stm = null;
        ResultSet rs = null;
        String sql = "SELECT ID_Proyecto as id, Constructora, Numero_Habitaciones as habitaciones, Ciudad from Proyecto p where Clasificacion = 'Casa Campestre' and ciudad in('Santa Marta', 'Cartagena', 'Barranquilla')";
        try{
            stm = conn.createStatement();
            rs = stm.executeQuery(sql);
            while(rs.next()) {
                ListarCasaCampestreVo vo = new ListarCasaCampestreVo();
                vo.setId(rs.getInt("ID"));
                vo.setConstructora(rs.getString("Constructora"));
                vo.setHabitaciones(rs.getInt("Habitaciones"));
                vo.setCiudad(rs.getString("Ciudad"));
                respuesta.add(vo);
            }
        }
        finally{
            if (rs != null){
                rs.close();
            }
            if (stm != null){
                stm.close();
            }   
            if(conn != null){
                conn.close();
            }
        }
        return respuesta;
    }
}
